# SanroStock Android — v1.0.2

URL utama: `https://pos.sanrotech.com/sanro-stock`  
Package ID: `com.sanrotech.stock`

Wrapper WebView ini dibuat khusus untuk SANRO dan menggunakan logo SANRO yang Anda berikan sebagai identitas launcher.

Fitur utama:
- HTTPS-only; halaman internal dibatasi ke `pos.sanrotech.com`.
- Session/cookie login dipertahankan.
- JavaScript + DOM Storage.
- Kamera/WebRTC untuk scan barcode.
- Android file chooser.
- `window.print()` diarahkan ke Android Print Service.
- Download membawa cookie login.
- WhatsApp/tel/email/link eksternal dibuka di aplikasi luar.
- SSL error selalu diblokir, tidak di-bypass.

Build:
1. Buka folder ini di Android Studio.
2. Pastikan JDK 17 dan Android SDK 35 tersedia.
3. Gradle Sync.
4. Build > Build App Bundles or APKs > Build APKs.

QA perangkat yang wajib dilakukan sebelum live: login/logout, session setelah reopen, scan barcode kamera, tombol Back, cetak, link WhatsApp, dan download.
